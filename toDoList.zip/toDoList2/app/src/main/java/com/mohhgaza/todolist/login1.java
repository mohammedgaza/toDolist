package com.mohhgaza.todolist;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class login1 extends AppCompatActivity {

    TextView textView8;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login1);
        textView8 =(TextView)findViewById(R.id.textView8);
    }

    public void onClick3(View view) {
        Intent textView8 = new Intent (this,registerA.class);
        startActivity(textView8);
    }
}