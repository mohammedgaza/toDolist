package com.mohhgaza.todolist;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class registerA extends AppCompatActivity {

    TextView textView4;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        textView4 =(TextView)findViewById(R.id.textView4);
    }


    public void onClick2(View view) {
        Intent textView4 = new Intent (this,login1.class);
        startActivity(textView4);
    }
}