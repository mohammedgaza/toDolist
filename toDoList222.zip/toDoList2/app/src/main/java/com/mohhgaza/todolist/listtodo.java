package com.mohhgaza.todolist;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.util.ArrayList;
import java.util.List;


public class listtodo extends AppCompatActivity {
    private RecyclerView rec11;
    private List <Listitem>listitems;
    private RecyclerView.Adapter adapter;
    FirebaseAuth mAuth;

    TextView textView19;
    ImageView imageView5;
    EditText editTextTextPersonName4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listtodo);
        rec11=findViewById(R.id.rec11);
        rec11.setHasFixedSize(true);
        rec11.setLayoutManager(new LinearLayoutManager(this));

        listitems = new ArrayList<>();
        for(int x=1;x<20;x++){
  Listitem listitem=new Listitem("Sea" +(x+1),"1 tasks");
  listitems.add(listitem);
        }

        adapter = new MyAdapter(this,listitems);
        rec11.setAdapter(adapter);

        textView19=findViewById(R.id.textView19);
        imageView5=findViewById(R.id.imageView5);
        editTextTextPersonName4=findViewById(R.id.editTextTextPersonName4);


        findViewById(R.id.textView19).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FirebaseAuth.getInstance().signOut();
                Toast.makeText(listtodo.this,"signed out",Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(listtodo.this,login1.class);
                startActivity(intent);
            }
        });

/*
        imageView5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mAuth = FirebaseAuth.getInstance();
                FirebaseUser user =mAuth.getCurrentUser();
                String uid = user.getUid();
               Listitem listitem = new Listitem( "","");
                listitem.setName(editTextTextPersonName4.getText().toString());
                listitems.add(listitem);

            }
        });
        */





    }






    public void onClick4(View view) {
        Intent imageView7 = new Intent (this,login1.class);
        startActivity(imageView7);
    }

    public void onClick7(View view) {
        Intent linearLayout2 = new Intent(this, listsBranch.class);
        startActivity(linearLayout2);
    }}
