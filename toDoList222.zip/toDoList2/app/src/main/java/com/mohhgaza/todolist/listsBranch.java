package com.mohhgaza.todolist;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;

public class listsBranch extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lists_branch);
    }


    public void onCheckboxClicked(View view) {
        // Is the view now checked?
        boolean checked = ((CheckBox) view).isChecked();
        CheckBox ch1 = findViewById(R.id.ch1);
        CheckBox ch2 = findViewById(R.id.ch2);
        CheckBox ch3 = findViewById(R.id.ch3);

        // Check which checkbox was clicked
        switch (view.getId()) {
            case R.id.ch3:
                if (checked){
                    ch3.setPaintFlags(ch3.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
                }
            else{
                    ch3.setPaintFlags(ch3.getPaintFlags() & (~Paint.STRIKE_THRU_TEXT_FLAG));
                }
                break;
            case R.id.ch2:
                if (checked){
                    ch2.setPaintFlags(ch2.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
                }
                else{
                    ch2.setPaintFlags(ch2.getPaintFlags() & (~Paint.STRIKE_THRU_TEXT_FLAG));
                }
                break;
            case R.id.ch1:
                if (checked){
                    ch1.setPaintFlags(ch1.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
                }
                else{
                    ch1.setPaintFlags(ch1.getPaintFlags() & (~Paint.STRIKE_THRU_TEXT_FLAG));
                }
                break;}


        }
    public void onClick6(View view) {
        Intent imageView10 = new Intent (this,listtodo.class);
        startActivity(imageView10);
    }
    public void onClick8(View view) {
        Intent imageView4 = new Intent (this,results.class);
        startActivity(imageView4);
    }

}
