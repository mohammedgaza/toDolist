package com.mohhgaza.todolist;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.adapterViewHolder> {
    EditText editTextTextPersonName4;

    private Context context;
    private List <Listitem>listitems;
    public MyAdapter(Context context, List listitem){
          this.context=context;
          this.listitems=listitem;
    }
    @NonNull
    @Override
    public adapterViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new adapterViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.rec11,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull adapterViewHolder holder, int position) {
        Listitem item = listitems.get(position);
        holder.name.setText("Gaza");
        holder.description.setText("5 tasks");
    }

    @Override
    public int getItemCount() {
        return listitems.size();
    }



    public class adapterViewHolder extends RecyclerView.ViewHolder {
        TextView name;
        TextView description;
        public adapterViewHolder(@NonNull View itemView) {
            super(itemView);

            name = itemView.findViewById(R.id.text33);
            description = itemView.findViewById(R.id.text44);

        }
    }
}
