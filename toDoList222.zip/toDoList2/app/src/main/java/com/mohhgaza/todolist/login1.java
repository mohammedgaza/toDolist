package com.mohhgaza.todolist;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class login1 extends AppCompatActivity {
    FirebaseAuth mAuth;
    EditText editTextTextEmailAddress2;
    EditText editTextTextPassword2;
    Button button2;
    TextView textView8;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login1);
        textView8 =(TextView)findViewById(R.id.textView8);
        mAuth = FirebaseAuth.getInstance();

        button2=findViewById(R.id.button2);
        editTextTextEmailAddress2=findViewById(R.id.editTextTextEmailAddress2);
        editTextTextPassword2=findViewById(R.id.editTextTextPassword2);



            button2.setOnClickListener(new View.OnClickListener(){

        @Override
        public void onClick(View view) {
            login1.this.doSignIn(editTextTextEmailAddress2.getText().toString(),editTextTextPassword2.getText().toString());
        }
    });
}

    private void  doSignIn (String email,String password){
        mAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {

                    @Override
                    public void onComplete(@NonNull final Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            Intent intent = new Intent(login1.this,listtodo.class);
                                    startActivity(intent);

                        }

                    }
                });

    }





    public void onClick3(View view) {
        Intent textView8 = new Intent (this,registerA.class);
        startActivity(textView8);
    }



   /* public void onClick5(View view) {
        Intent button2 = new Intent (this,listtodo.class);
        startActivity(button2);
    }*/
}
