package com.mohhgaza.todolist;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.Map;

public class registerA extends AppCompatActivity {

    TextView textView4;
    FirebaseAuth mAuth;
    Button button;
    EditText editTextTextPersonName2;
    EditText editTextTextPassword;
    EditText editTextTextEmailAddress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        textView4 =(TextView)findViewById(R.id.textView4);

        mAuth = FirebaseAuth.getInstance();


        button=findViewById(R.id.button);
        editTextTextPersonName2=findViewById(R.id.editTextTextPersonName2);
        editTextTextPassword=findViewById(R.id.editTextTextPassword);
        editTextTextEmailAddress=findViewById(R.id.editTextTextEmailAddress);


        button.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view) {
                registerA.this.doSignUp(editTextTextEmailAddress.getText().toString(),editTextTextPassword.getText().toString());
            }
        });
    }


private void  doSignUp (String email,String password){
    mAuth.createUserWithEmailAndPassword(email, password)
            .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {

                @Override
                public void onComplete(@NonNull final Task<AuthResult> task) {
                    if (task.isSuccessful()) {
                        FirebaseUser user = mAuth.getCurrentUser();
                        String uid = user.getUid();

                        Map<String,Object> data = new HashMap<>();
                        data.put("uid",uid);
                        FirebaseDatabase.getInstance().getReference("User").child(uid).setValue(data).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Toast.makeText(registerA.this,task.getException().getLocalizedMessage(),Toast.LENGTH_SHORT).show();
                                Log.d("error",e.getLocalizedMessage());
                            }
                        }).addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void aVoid) {
                                Intent intent = new Intent (registerA.this,login1.class);
                                startActivity(intent);
                            }
                        });
                    }

                }
            });

}

    public void onClick2(View view) {
        Intent textView4 = new Intent (this,login1.class);
        startActivity(textView4);
    }
}